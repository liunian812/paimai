-- -----------------------------
-- 金方时代数据库备份 
-- BY-丰台技术部
-- Host     : localhost
-- Port     : 3306
-- Database : jfsd_thinkphp
-- 
-- Part : #1
-- Date : 2015-10-29 16:55:25
-- -----------------------------

SET FOREIGN_KEY_CHECKS = 0;


-- -----------------------------
-- Table structure for `jfsd_admin`
-- -----------------------------
DROP TABLE IF EXISTS `jfsd_admin`;
;

-- -----------------------------
-- Records of `jfsd_admin`
-- -----------------------------
INSERT INTO `jfsd_admin` VALUES ('1', 'bjjfsd', '69112c0043bf462cda2d4e39e67fc5f4', '', '1', '1', '1436174970', '1442381626', '66', '1446108861', '2130706433', '', '');
INSERT INTO `jfsd_admin` VALUES ('2', 'admin', 'd404d520663fb1e6ab380640cb7c30d6', '', '1', '1', '1436174970', '1446020763', '18', '1446108808', '2130706433', '', '');

-- -----------------------------
-- Table structure for `jfsd_auth_group`
-- -----------------------------
DROP TABLE IF EXISTS `jfsd_auth_group`;
;

-- -----------------------------
-- Records of `jfsd_auth_group`
-- -----------------------------
INSERT INTO `jfsd_auth_group` VALUES ('1', '管理员', '1', '1,22,23,68,69,72,74,75,76,4,2,18,25,30,31,32,5,10,41,42,43,34,53,33,49,50,51,6,39,58,59,60,61,62,63,64,37,38,67');

-- -----------------------------
-- Table structure for `jfsd_auth_group_access`
-- -----------------------------
DROP TABLE IF EXISTS `jfsd_auth_group_access`;
;


-- -----------------------------
-- Table structure for `jfsd_auth_rule`
-- -----------------------------
DROP TABLE IF EXISTS `jfsd_auth_rule`;
;

-- -----------------------------
-- Records of `jfsd_auth_rule`
-- -----------------------------
INSERT INTO `jfsd_auth_rule` VALUES ('1', '0', 'Admin/Index/index', '网站首页', '1', '0', '1', '', '0');
INSERT INTO `jfsd_auth_rule` VALUES ('2', '4', 'Admin/Config/index', '基本信息', '1', '0', '1', '', '0');
INSERT INTO `jfsd_auth_rule` VALUES ('4', '0', 'Admin/Config/index', '系统管理', '1', '0', '1', '', '0');
INSERT INTO `jfsd_auth_rule` VALUES ('5', '0', 'Admin/Category/index', '内容管理', '1', '0', '1', '', '0');
INSERT INTO `jfsd_auth_rule` VALUES ('6', '0', 'Admin/Banner/index', '广告管理', '1', '0', '1', '', '0');
INSERT INTO `jfsd_auth_rule` VALUES ('7', '4', 'Admin/Config/group', '配置管理', '1', '0', '1', '', '0');
INSERT INTO `jfsd_auth_rule` VALUES ('9', '4', 'Admin/Menu/index', '菜单管理', '1', '0', '1', '', '0');
INSERT INTO `jfsd_auth_rule` VALUES ('10', '5', 'Admin/Category/index', '栏目管理', '1', '0', '1', '', '10');
INSERT INTO `jfsd_auth_rule` VALUES ('15', '9', 'Admin/Menu/add', '新增', '1', '1', '1', '', '0');
INSERT INTO `jfsd_auth_rule` VALUES ('16', '9', 'Admin/Menu/edit', '修改', '1', '1', '1', '', '0');
INSERT INTO `jfsd_auth_rule` VALUES ('17', '9', 'Admin/Menu/del', '删除', '1', '1', '1', '', '0');
INSERT INTO `jfsd_auth_rule` VALUES ('18', '2', 'Admin/Config/save', '保存修改', '1', '1', '1', '', '0');
INSERT INTO `jfsd_auth_rule` VALUES ('19', '7', 'Admin/Config/add', '新增', '1', '1', '1', '', '0');
INSERT INTO `jfsd_auth_rule` VALUES ('20', '7', 'Admin/Config/edit', '修改', '1', '1', '1', '', '0');
INSERT INTO `jfsd_auth_rule` VALUES ('21', '7', 'Admin/Config/del', '删除', '1', '1', '1', '', '0');
INSERT INTO `jfsd_auth_rule` VALUES ('22', '1', 'Admin/Index/index', '网站首页', '1', '0', '1', '', '0');
INSERT INTO `jfsd_auth_rule` VALUES ('23', '1', 'Admin/Index/help', '帮助中心', '1', '0', '1', '', '0');
INSERT INTO `jfsd_auth_rule` VALUES ('24', '4', 'Admin/Auth/index', '权限管理', '1', '0', '1', '', '0');
INSERT INTO `jfsd_auth_rule` VALUES ('25', '4', 'Admin/Admin/index', '管理员', '1', '0', '1', '', '0');
INSERT INTO `jfsd_auth_rule` VALUES ('26', '24', 'Admin/Auth/add', '新增', '1', '1', '1', '', '0');
INSERT INTO `jfsd_auth_rule` VALUES ('27', '24', 'Admin/Auth/edit', '修改', '1', '1', '1', '', '0');
INSERT INTO `jfsd_auth_rule` VALUES ('28', '24', 'Admin/Auth/del', '删除', '1', '1', '1', '', '0');
INSERT INTO `jfsd_auth_rule` VALUES ('29', '24', 'Admin/Auth/access', '分配', '1', '1', '1', '', '0');
INSERT INTO `jfsd_auth_rule` VALUES ('30', '25', 'Admin/Admin/add', '新增', '1', '1', '1', '', '0');
INSERT INTO `jfsd_auth_rule` VALUES ('31', '25', 'Admin/Admin/edit', '修改', '1', '1', '1', '', '0');
INSERT INTO `jfsd_auth_rule` VALUES ('32', '25', 'Admin/Admin/del', '删除', '1', '1', '1', '', '0');
INSERT INTO `jfsd_auth_rule` VALUES ('33', '5', 'Admin/News/index', '新闻管理', '1', '0', '1', '', '0');
INSERT INTO `jfsd_auth_rule` VALUES ('34', '5', 'Admin/Pages/index', '单页管理', '1', '0', '1', '', '9');
INSERT INTO `jfsd_auth_rule` VALUES ('35', '5', 'Admin/Product/index', '产品管理', '1', '0', '1', '', '0');
INSERT INTO `jfsd_auth_rule` VALUES ('36', '0', 'Admin/Message/index', '在线留言', '1', '0', '1', '', '0');
INSERT INTO `jfsd_auth_rule` VALUES ('37', '0', 'Admin/Attachment/index', '附件管理', '1', '0', '1', '', '0');
INSERT INTO `jfsd_auth_rule` VALUES ('38', '37', 'Admin/Attachment/index', '附件列表', '1', '0', '1', '', '0');
INSERT INTO `jfsd_auth_rule` VALUES ('39', '6', 'Admin/Banner/index', '广告列表', '1', '0', '1', '', '0');
INSERT INTO `jfsd_auth_rule` VALUES ('40', '36', 'Admin/Message/index', '留言列表', '1', '0', '1', '', '0');
INSERT INTO `jfsd_auth_rule` VALUES ('41', '10', 'Admin/Category/add', '新增', '1', '0', '1', '', '0');
INSERT INTO `jfsd_auth_rule` VALUES ('42', '10', 'Admin/Category/edit', '修改', '1', '0', '1', '', '0');
INSERT INTO `jfsd_auth_rule` VALUES ('43', '10', 'Admin/Category/del', '删除', '1', '0', '1', '', '0');
INSERT INTO `jfsd_auth_rule` VALUES ('49', '33', 'Admin/News/add', '新增', '1', '0', '1', '', '0');
INSERT INTO `jfsd_auth_rule` VALUES ('50', '33', 'Admin/News/edit', '修改', '1', '0', '1', '', '0');
INSERT INTO `jfsd_auth_rule` VALUES ('51', '33', 'Admin/News/del', '删除', '1', '0', '1', '', '0');
INSERT INTO `jfsd_auth_rule` VALUES ('53', '34', 'Admin/Pages/edit', '修改', '1', '0', '1', '', '0');
INSERT INTO `jfsd_auth_rule` VALUES ('54', '35', 'Admin/Product/add', '新增', '1', '0', '1', '', '0');
INSERT INTO `jfsd_auth_rule` VALUES ('55', '35', 'Admin/Product/edit', '修改', '1', '0', '1', '', '0');
INSERT INTO `jfsd_auth_rule` VALUES ('56', '35', 'Admin/Product/del', '删除', '1', '0', '1', '', '0');
INSERT INTO `jfsd_auth_rule` VALUES ('57', '35', 'Admin/Product/position', '推荐位', '1', '0', '1', '', '0');
INSERT INTO `jfsd_auth_rule` VALUES ('58', '39', 'Admin/Banner/add', '新增', '1', '0', '1', '', '0');
INSERT INTO `jfsd_auth_rule` VALUES ('59', '39', 'Admin/Banner/edit', '修改', '1', '0', '1', '', '0');
INSERT INTO `jfsd_auth_rule` VALUES ('60', '39', 'Admin/Banner/del', '删除', '1', '0', '1', '', '0');
INSERT INTO `jfsd_auth_rule` VALUES ('61', '39', 'Admin/Banner/dList', '列表信息', '1', '0', '1', '', '0');
INSERT INTO `jfsd_auth_rule` VALUES ('62', '39', 'Admin/Banner/dAdd', '列表信息新增', '1', '0', '1', '', '0');
INSERT INTO `jfsd_auth_rule` VALUES ('63', '39', 'Admin/Banner/dEdit', '列表信息修改', '1', '0', '1', '', '0');
INSERT INTO `jfsd_auth_rule` VALUES ('64', '39', 'Admin/Banner/dDel', '列表信息删除', '1', '0', '1', '', '0');
INSERT INTO `jfsd_auth_rule` VALUES ('65', '40', 'Admin/Message/show', '查看', '1', '0', '1', '', '0');
INSERT INTO `jfsd_auth_rule` VALUES ('66', '40', 'Admin/Message/del', '删除', '1', '0', '1', '', '0');
INSERT INTO `jfsd_auth_rule` VALUES ('67', '38', 'Admin/Attachment/delFile', '删除', '1', '0', '1', '', '0');
INSERT INTO `jfsd_auth_rule` VALUES ('68', '1', 'Admin/Index/deleteCache', '更新缓存', '1', '0', '1', '', '0');
INSERT INTO `jfsd_auth_rule` VALUES ('69', '1', 'Admin/Index/editPassword', '修改密码', '1', '0', '1', '', '0');
INSERT INTO `jfsd_auth_rule` VALUES ('71', '33', 'Admin/News/position', '推荐位', '1', '1', '1', '', '0');
INSERT INTO `jfsd_auth_rule` VALUES ('72', '1', 'Admin/Database/index', '数据库管理', '1', '0', '1', '', '0');
INSERT INTO `jfsd_auth_rule` VALUES ('73', '5', 'Admin/Sping/index', '商品管理', '1', '0', '1', '', '0');
INSERT INTO `jfsd_auth_rule` VALUES ('74', '72', 'Admin/Database/export', '数据库备份', '1', '1', '1', '', '0');
INSERT INTO `jfsd_auth_rule` VALUES ('75', '72', 'Admin/Database/del', '备份文件删除', '1', '1', '1', '', '0');
INSERT INTO `jfsd_auth_rule` VALUES ('76', '72', 'Admin/Database/lists', '备份文件列表', '1', '0', '1', '', '0');
INSERT INTO `jfsd_auth_rule` VALUES ('77', '73', 'Admin/Sping/add', '新增', '1', '0', '1', '', '0');
INSERT INTO `jfsd_auth_rule` VALUES ('78', '73', 'Admin/Sping/edit', '修改', '1', '0', '1', '', '0');
INSERT INTO `jfsd_auth_rule` VALUES ('79', '73', 'Admin/Sping/del', '删除', '1', '0', '1', '', '0');
INSERT INTO `jfsd_auth_rule` VALUES ('80', '73', 'Admin/Sping/position', '推荐位', '1', '1', '1', '', '0');

-- -----------------------------
-- Table structure for `jfsd_banner`
-- -----------------------------
DROP TABLE IF EXISTS `jfsd_banner`;
;

-- -----------------------------
-- Records of `jfsd_banner`
-- -----------------------------
INSERT INTO `jfsd_banner` VALUES ('1', '1', '广告位1', '0', '1', '0', '', '', '0');
INSERT INTO `jfsd_banner` VALUES ('2', '1', '广告位2', '1', '0', '1', '', '', '0');

-- -----------------------------
-- Table structure for `jfsd_banner_data`
-- -----------------------------
DROP TABLE IF EXISTS `jfsd_banner_data`;
;

-- -----------------------------
-- Records of `jfsd_banner_data`
-- -----------------------------
INSERT INTO `jfsd_banner_data` VALUES ('1', '1', '哪一个答案最能贴切地描绘你一般的感受或行', '', '', '', '0');

-- -----------------------------
-- Table structure for `jfsd_category`
-- -----------------------------
DROP TABLE IF EXISTS `jfsd_category`;
;

-- -----------------------------
-- Records of `jfsd_category`
-- -----------------------------
INSERT INTO `jfsd_category` VALUES ('1', '0', '商品管理', '', 'Sping', '', '', '', 'a:10:{s:11:\"allow_child\";s:1:\"0\";s:8:\"page_num\";s:0:\"\";s:13:\"list_template\";s:0:\"\";s:13:\"show_template\";s:0:\"\";s:13:\"page_template\";s:0:\"\";s:9:\"img_width\";s:0:\"\";s:10:\"img_height\";s:0:\"\";s:10:\"meta_title\";s:0:\"\";s:13:\"meta_keywords\";s:0:\"\";s:16:\"meta_description\";s:0:\"\";}', '1', '0');

-- -----------------------------
-- Table structure for `jfsd_config`
-- -----------------------------
DROP TABLE IF EXISTS `jfsd_config`;
;

-- -----------------------------
-- Records of `jfsd_config`
-- -----------------------------
INSERT INTO `jfsd_config` VALUES ('1', 'WEB_SITE_TITLE', '0', '网站标题', '1', '', '网站标题前台显示标题', '1378898976', '1436345744', '1', '金方时代内容管理框架', '0');
INSERT INTO `jfsd_config` VALUES ('2', 'WEB_SITE_DESCRIPTION', '2', '网站描述', '1', '', '网站搜索引擎描述', '1378898976', '1379235841', '1', '金方时代内容管理框架', '1');
INSERT INTO `jfsd_config` VALUES ('3', 'WEB_SITE_KEYWORD', '2', '网站关键字', '1', '', '网站搜索引擎关键字', '1378898976', '1381390100', '1', '金方时代内容管理框架', '8');
INSERT INTO `jfsd_config` VALUES ('5', 'CONFIG_TYPE_LIST', '3', '配置类型列表', '0', '', '主要用于数据解析和页面表单的生成', '1378898976', '1442375762', '1', '0:数字\r\n1:字符\r\n2:文本\r\n3:数组\r\n4:枚举', '2');
INSERT INTO `jfsd_config` VALUES ('7', 'CONFIG_GROUP_LIST', '3', '配置分组', '0', '', '配置分组', '1379228036', '1445934744', '1', '1:基本\r\n2:前台', '4');
INSERT INTO `jfsd_config` VALUES ('9', 'ADMIN_LIST_ROWS', '0', '后台每页记录数', '4', '', '后台数据每页显示记录数，默认10', '1379503896', '1436427099', '1', '15', '20');
INSERT INTO `jfsd_config` VALUES ('10', 'USER_ALLOW_REGISTER', '4', '是否允许用户注册', '3', '0:关闭注册\r\n1:允许注册', '是否开放用户注册', '1379504487', '1379504580', '1', '1', '3');
INSERT INTO `jfsd_config` VALUES ('12', 'SHOW_LIST_ROWS', '0', '前台显示列表显示数量', '2', '', '前台显示列表显示数量：默认', '1386645376', '1437048910', '1', '12', '0');
INSERT INTO `jfsd_config` VALUES ('13', 'ADMIN_ALLOW_IP', '2', '后台允许访问IP', '0', '', '多个用逗号分隔，如果不配置表示不限制IP访问', '1387165454', '1442369565', '1', '', '12');
INSERT INTO `jfsd_config` VALUES ('14', 'SHOW_PAGE_TRACE', '4', '是否显示页面Trace', '4', '0:关闭\r\n1:开启', '是否显示页面Trace信息', '1387165685', '1387165685', '1', '0', '1');
INSERT INTO `jfsd_config` VALUES ('15', 'IS_ROOT', '3', '超级管理员', '0', '', '超级管理员用户uid', '1435728710', '1442310051', '1', '1', '0');
INSERT INTO `jfsd_config` VALUES ('16', 'CATEGORY_TYPE', '3', '栏目类型', '2', '', '栏目类型', '1436250193', '1446105439', '1', 'News:新闻\r\nPages:单页\r\nProduct:产品\r\nSping:商品', '0');
INSERT INTO `jfsd_config` VALUES ('19', 'BANNER_TYPE', '3', '广告位类型', '0', '', '广告位类型', '1436770102', '1442384478', '1', '1:单条\r\n2:多条', '0');
INSERT INTO `jfsd_config` VALUES ('20', 'COPYRIGHT', '2', '底部copyRight', '2', '', '底部copyRight', '1437116639', '1437116639', '1', '版权所有：北京欧韵美业管理咨询有限公司  京ICP 证070504 号', '0');

-- -----------------------------
-- Table structure for `jfsd_link`
-- -----------------------------
DROP TABLE IF EXISTS `jfsd_link`;
;


-- -----------------------------
-- Table structure for `jfsd_message`
-- -----------------------------
DROP TABLE IF EXISTS `jfsd_message`;
;


-- -----------------------------
-- Table structure for `jfsd_news`
-- -----------------------------
DROP TABLE IF EXISTS `jfsd_news`;
;

-- -----------------------------
-- Records of `jfsd_news`
-- -----------------------------
INSERT INTO `jfsd_news` VALUES ('1', 'Sping', '1', '万方研发服务中心', '111', '', '', '&lt;p&gt;1111111111111&lt;/p&gt;', 'a:4:{s:7:\"field_1\";s:9:\"111111111\";s:7:\"field_2\";s:13:\"1111111111111\";s:7:\"field_3\";s:0:\"\";s:7:\"field_4\";s:31:\"&lt;p&gt;111111111111&lt;/p&gt;\";}', '0', '1446105517', '1446106070', '0', '0', '1');

-- -----------------------------
-- Table structure for `jfsd_pages`
-- -----------------------------
DROP TABLE IF EXISTS `jfsd_pages`;
;


-- -----------------------------
-- Table structure for `jfsd_product`
-- -----------------------------
DROP TABLE IF EXISTS `jfsd_product`;
;


-- -----------------------------
-- Table structure for `jfsd_search`
-- -----------------------------
DROP TABLE IF EXISTS `jfsd_search`;
;


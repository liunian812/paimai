-- -----------------------------
-- 金方时代数据库备份 
-- BY-丰台技术部
-- Host     : localhost
-- Port     : 3306
-- Database : jfsd_yuyingbo_paimai
-- 
-- Part : #1
-- Date : 2015-11-16 09:51:56
-- -----------------------------

SET FOREIGN_KEY_CHECKS = 0;


-- -----------------------------
-- Table structure for `jfsd_admin`
-- -----------------------------
DROP TABLE IF EXISTS `jfsd_admin`;
;

-- -----------------------------
-- Records of `jfsd_admin`
-- -----------------------------
INSERT INTO `jfsd_admin` VALUES ('1', 'bjjfsd', '69112c0043bf462cda2d4e39e67fc5f4', '', '1', '1', '1436174970', '1442381626', '74', '1447638676', '2093676230', '', '');
INSERT INTO `jfsd_admin` VALUES ('2', 'admin', 'd404d520663fb1e6ab380640cb7c30d6', '', '1', '1', '1436174970', '1446020763', '18', '1446108808', '2130706433', '', '');

-- -----------------------------
-- Table structure for `jfsd_auth_group`
-- -----------------------------
DROP TABLE IF EXISTS `jfsd_auth_group`;
;

-- -----------------------------
-- Records of `jfsd_auth_group`
-- -----------------------------
INSERT INTO `jfsd_auth_group` VALUES ('1', '管理员', '1', '1,22,23,68,69,72,74,75,76,4,2,18,25,30,31,32,5,10,41,42,43,34,53,33,49,50,51,6,39,58,59,60,61,62,63,64,37,38,67');

-- -----------------------------
-- Table structure for `jfsd_auth_group_access`
-- -----------------------------
DROP TABLE IF EXISTS `jfsd_auth_group_access`;
;


-- -----------------------------
-- Table structure for `jfsd_auth_rule`
-- -----------------------------
DROP TABLE IF EXISTS `jfsd_auth_rule`;
;

-- -----------------------------
-- Records of `jfsd_auth_rule`
-- -----------------------------
INSERT INTO `jfsd_auth_rule` VALUES ('1', '0', 'Admin/Index/index', '网站首页', '1', '0', '1', '', '0');
INSERT INTO `jfsd_auth_rule` VALUES ('2', '4', 'Admin/Config/index', '基本信息', '1', '0', '1', '', '0');
INSERT INTO `jfsd_auth_rule` VALUES ('4', '0', 'Admin/Config/index', '系统管理', '1', '0', '1', '', '0');
INSERT INTO `jfsd_auth_rule` VALUES ('5', '0', 'Admin/Category/index', '内容管理', '1', '0', '1', '', '0');
INSERT INTO `jfsd_auth_rule` VALUES ('6', '0', 'Admin/Banner/index', '广告管理', '1', '0', '1', '', '0');
INSERT INTO `jfsd_auth_rule` VALUES ('7', '4', 'Admin/Config/group', '配置管理', '1', '0', '1', '', '0');
INSERT INTO `jfsd_auth_rule` VALUES ('9', '4', 'Admin/Menu/index', '菜单管理', '1', '0', '1', '', '0');
INSERT INTO `jfsd_auth_rule` VALUES ('10', '5', 'Admin/Category/index', '栏目管理', '1', '0', '1', '', '10');
INSERT INTO `jfsd_auth_rule` VALUES ('15', '9', 'Admin/Menu/add', '新增', '1', '1', '1', '', '0');
INSERT INTO `jfsd_auth_rule` VALUES ('16', '9', 'Admin/Menu/edit', '修改', '1', '1', '1', '', '0');
INSERT INTO `jfsd_auth_rule` VALUES ('17', '9', 'Admin/Menu/del', '删除', '1', '1', '1', '', '0');
INSERT INTO `jfsd_auth_rule` VALUES ('18', '2', 'Admin/Config/save', '保存修改', '1', '1', '1', '', '0');
INSERT INTO `jfsd_auth_rule` VALUES ('19', '7', 'Admin/Config/add', '新增', '1', '1', '1', '', '0');
INSERT INTO `jfsd_auth_rule` VALUES ('20', '7', 'Admin/Config/edit', '修改', '1', '1', '1', '', '0');
INSERT INTO `jfsd_auth_rule` VALUES ('21', '7', 'Admin/Config/del', '删除', '1', '1', '1', '', '0');
INSERT INTO `jfsd_auth_rule` VALUES ('22', '1', 'Admin/Index/index', '网站首页', '1', '0', '1', '', '0');
INSERT INTO `jfsd_auth_rule` VALUES ('23', '1', 'Admin/Index/help', '帮助中心', '1', '0', '1', '', '0');
INSERT INTO `jfsd_auth_rule` VALUES ('24', '4', 'Admin/Auth/index', '权限管理', '1', '0', '1', '', '0');
INSERT INTO `jfsd_auth_rule` VALUES ('25', '4', 'Admin/Admin/index', '管理员', '1', '0', '1', '', '0');
INSERT INTO `jfsd_auth_rule` VALUES ('26', '24', 'Admin/Auth/add', '新增', '1', '1', '1', '', '0');
INSERT INTO `jfsd_auth_rule` VALUES ('27', '24', 'Admin/Auth/edit', '修改', '1', '1', '1', '', '0');
INSERT INTO `jfsd_auth_rule` VALUES ('28', '24', 'Admin/Auth/del', '删除', '1', '1', '1', '', '0');
INSERT INTO `jfsd_auth_rule` VALUES ('29', '24', 'Admin/Auth/access', '分配', '1', '1', '1', '', '0');
INSERT INTO `jfsd_auth_rule` VALUES ('30', '25', 'Admin/Admin/add', '新增', '1', '1', '1', '', '0');
INSERT INTO `jfsd_auth_rule` VALUES ('31', '25', 'Admin/Admin/edit', '修改', '1', '1', '1', '', '0');
INSERT INTO `jfsd_auth_rule` VALUES ('32', '25', 'Admin/Admin/del', '删除', '1', '1', '1', '', '0');
INSERT INTO `jfsd_auth_rule` VALUES ('33', '5', 'Admin/News/index', '新闻管理', '1', '0', '1', '', '0');
INSERT INTO `jfsd_auth_rule` VALUES ('34', '5', 'Admin/Pages/index', '单页管理', '1', '0', '1', '', '9');
INSERT INTO `jfsd_auth_rule` VALUES ('35', '81', 'Admin/Product/index', '加价拍', '1', '0', '1', '', '0');
INSERT INTO `jfsd_auth_rule` VALUES ('36', '0', 'Admin/Message/index', '在线留言', '1', '0', '1', '', '0');
INSERT INTO `jfsd_auth_rule` VALUES ('37', '0', 'Admin/Attachment/index', '附件管理', '1', '0', '1', '', '0');
INSERT INTO `jfsd_auth_rule` VALUES ('38', '37', 'Admin/Attachment/index', '附件列表', '1', '0', '1', '', '0');
INSERT INTO `jfsd_auth_rule` VALUES ('39', '6', 'Admin/Banner/index', '广告列表', '1', '0', '1', '', '0');
INSERT INTO `jfsd_auth_rule` VALUES ('40', '36', 'Admin/Message/index', '留言列表', '1', '0', '1', '', '0');
INSERT INTO `jfsd_auth_rule` VALUES ('41', '10', 'Admin/Category/add', '新增', '1', '0', '1', '', '0');
INSERT INTO `jfsd_auth_rule` VALUES ('42', '10', 'Admin/Category/edit', '修改', '1', '0', '1', '', '0');
INSERT INTO `jfsd_auth_rule` VALUES ('43', '10', 'Admin/Category/del', '删除', '1', '0', '1', '', '0');
INSERT INTO `jfsd_auth_rule` VALUES ('49', '33', 'Admin/News/add', '新增', '1', '0', '1', '', '0');
INSERT INTO `jfsd_auth_rule` VALUES ('50', '33', 'Admin/News/edit', '修改', '1', '0', '1', '', '0');
INSERT INTO `jfsd_auth_rule` VALUES ('51', '33', 'Admin/News/del', '删除', '1', '0', '1', '', '0');
INSERT INTO `jfsd_auth_rule` VALUES ('53', '34', 'Admin/Pages/edit', '修改', '1', '0', '1', '', '0');
INSERT INTO `jfsd_auth_rule` VALUES ('56', '35', 'Admin/Product/del', '删除', '1', '0', '1', '', '0');
INSERT INTO `jfsd_auth_rule` VALUES ('57', '35', 'Admin/Product/position', '推荐位', '1', '0', '1', '', '0');
INSERT INTO `jfsd_auth_rule` VALUES ('58', '39', 'Admin/Banner/add', '新增', '1', '0', '1', '', '0');
INSERT INTO `jfsd_auth_rule` VALUES ('59', '39', 'Admin/Banner/edit', '修改', '1', '0', '1', '', '0');
INSERT INTO `jfsd_auth_rule` VALUES ('60', '39', 'Admin/Banner/del', '删除', '1', '0', '1', '', '0');
INSERT INTO `jfsd_auth_rule` VALUES ('61', '39', 'Admin/Banner/dList', '列表信息', '1', '0', '1', '', '0');
INSERT INTO `jfsd_auth_rule` VALUES ('62', '39', 'Admin/Banner/dAdd', '列表信息新增', '1', '0', '1', '', '0');
INSERT INTO `jfsd_auth_rule` VALUES ('63', '39', 'Admin/Banner/dEdit', '列表信息修改', '1', '0', '1', '', '0');
INSERT INTO `jfsd_auth_rule` VALUES ('64', '39', 'Admin/Banner/dDel', '列表信息删除', '1', '0', '1', '', '0');
INSERT INTO `jfsd_auth_rule` VALUES ('65', '40', 'Admin/Message/show', '查看', '1', '0', '1', '', '0');
INSERT INTO `jfsd_auth_rule` VALUES ('66', '40', 'Admin/Message/del', '删除', '1', '0', '1', '', '0');
INSERT INTO `jfsd_auth_rule` VALUES ('67', '38', 'Admin/Attachment/delFile', '删除', '1', '0', '1', '', '0');
INSERT INTO `jfsd_auth_rule` VALUES ('68', '1', 'Admin/Index/deleteCache', '更新缓存', '1', '0', '1', '', '0');
INSERT INTO `jfsd_auth_rule` VALUES ('69', '1', 'Admin/Index/editPassword', '修改密码', '1', '0', '1', '', '0');
INSERT INTO `jfsd_auth_rule` VALUES ('71', '33', 'Admin/News/position', '推荐位', '1', '1', '1', '', '0');
INSERT INTO `jfsd_auth_rule` VALUES ('72', '1', 'Admin/Database/index', '数据库管理', '1', '0', '1', '', '0');
INSERT INTO `jfsd_auth_rule` VALUES ('73', '81', 'Admin/Product2/index', '竞速拍', '1', '0', '1', '', '0');
INSERT INTO `jfsd_auth_rule` VALUES ('74', '72', 'Admin/Database/export', '数据库备份', '1', '1', '1', '', '0');
INSERT INTO `jfsd_auth_rule` VALUES ('75', '72', 'Admin/Database/del', '备份文件删除', '1', '1', '1', '', '0');
INSERT INTO `jfsd_auth_rule` VALUES ('76', '72', 'Admin/Database/lists', '备份文件列表', '1', '0', '1', '', '0');
INSERT INTO `jfsd_auth_rule` VALUES ('79', '73', 'Admin/Product2/del', '删除', '1', '0', '1', '', '0');
INSERT INTO `jfsd_auth_rule` VALUES ('80', '73', 'Admin/Product2/position', '推荐位', '1', '1', '1', '', '0');
INSERT INTO `jfsd_auth_rule` VALUES ('81', '0', 'Admin/Product/index', '拍卖管理', '1', '0', '1', '', '0');
INSERT INTO `jfsd_auth_rule` VALUES ('82', '81', 'Admin/Product3/index', '秒杀拍', '1', '0', '1', '', '0');
INSERT INTO `jfsd_auth_rule` VALUES ('83', '82', 'Admin/Product3/del', '删除', '1', '1', '1', '', '0');
INSERT INTO `jfsd_auth_rule` VALUES ('84', '82', 'Admin/Product3/position', '推荐', '1', '1', '1', '', '0');
INSERT INTO `jfsd_auth_rule` VALUES ('85', '0', 'Admin/Shop/index', '店铺管理', '1', '0', '1', '', '0');
INSERT INTO `jfsd_auth_rule` VALUES ('86', '85', 'Admin/Shop/index', '店铺列表', '1', '0', '1', '', '0');

-- -----------------------------
-- Table structure for `jfsd_banner`
-- -----------------------------
DROP TABLE IF EXISTS `jfsd_banner`;
;

-- -----------------------------
-- Records of `jfsd_banner`
-- -----------------------------
INSERT INTO `jfsd_banner` VALUES ('1', '2', '首页-轮播广告', '1', '1', '0', '640', '350', '0');
INSERT INTO `jfsd_banner` VALUES ('2', '1', '首页-活动专区-上', '1', '1', '0', '600', '230', '0');
INSERT INTO `jfsd_banner` VALUES ('3', '2', '首页-特价活动', '1', '1', '0', '600', '230', '0');
INSERT INTO `jfsd_banner` VALUES ('4', '2', '首页-活动专区-下', '1', '1', '0', '600', '230', '0');
INSERT INTO `jfsd_banner` VALUES ('5', '2', '新闻知识', '1', '1', '1', '600', '267', '0');

-- -----------------------------
-- Table structure for `jfsd_banner_data`
-- -----------------------------
DROP TABLE IF EXISTS `jfsd_banner_data`;
;

-- -----------------------------
-- Records of `jfsd_banner_data`
-- -----------------------------
INSERT INTO `jfsd_banner_data` VALUES ('1', '1', '1', '', 'javascript:;', 'Content/2015-11-12/5644261926596.jpg', '0');
INSERT INTO `jfsd_banner_data` VALUES ('2', '1', '2', '', 'javascript:;', 'Content/2015-11-12/56442642e7124.jpg', '0');
INSERT INTO `jfsd_banner_data` VALUES ('3', '1', '3', '', 'javascript:;', 'Content/2015-11-12/56442652dff85.jpg', '0');
INSERT INTO `jfsd_banner_data` VALUES ('4', '2', '凡赛珠宝第一百一十场珠宝专场', '', 'javascript:;', 'Content/2015-11-12/564426886a10a.jpg', '0');
INSERT INTO `jfsd_banner_data` VALUES ('5', '3', '凡赛珠宝第一百一十场珠宝专场', '', 'javascript:;', 'Content/2015-11-12/564426ceccb45.jpg', '0');
INSERT INTO `jfsd_banner_data` VALUES ('6', '4', '凡赛珠宝第一百一十场珠宝专场', '', 'javascript:;', 'Content/2015-11-12/564426f785bd6.jpg', '0');
INSERT INTO `jfsd_banner_data` VALUES ('7', '4', '凡赛珠宝第一百一十场珠宝专场', '', 'javascript:;', 'Content/2015-11-12/5644270acc90d.jpg', '0');
INSERT INTO `jfsd_banner_data` VALUES ('8', '5', '翡翠的冬天：上万元的并不能保值', '', 'javascript:;', 'Content/2015-11-13/564598ab36395.jpg', '100');
INSERT INTO `jfsd_banner_data` VALUES ('9', '5', '翡翠的冬天：上万元的并不能保值', '翡翠的冬天：上万元的并不能保值翡翠的冬天：上万元的并不能保值翡翠的冬天：上万元的并不能保值翡翠的冬天：上万元的并不能保值翡翠的冬天：上万元的并不能保值翡翠的冬天：上万元的并不能保值', 'javascript:;', 'Content/2015-11-13/564598e4bec51.jpg', '0');
INSERT INTO `jfsd_banner_data` VALUES ('10', '5', '翡翠的冬天：上万元的并不能保值', '翡翠的冬天：上万元的并不能保值翡翠的冬天：上万元的并不能保值翡翠的冬天：上万元的并不能保值翡翠的冬天：上万元的并不能保值', 'javascript:;', 'Content/2015-11-13/56459a5213d87.jpg', '0');

-- -----------------------------
-- Table structure for `jfsd_category`
-- -----------------------------
DROP TABLE IF EXISTS `jfsd_category`;
;


-- -----------------------------
-- Table structure for `jfsd_config`
-- -----------------------------
DROP TABLE IF EXISTS `jfsd_config`;
;

-- -----------------------------
-- Records of `jfsd_config`
-- -----------------------------
INSERT INTO `jfsd_config` VALUES ('1', 'WEB_SITE_TITLE', '0', '标题', '1', '', '网站标题', '1378898976', '1444807000', '1', '金方时代', '0');
INSERT INTO `jfsd_config` VALUES ('2', 'WEB_SITE_DESCRIPTION', '2', '网站描述', '1', '', '网站搜索引擎描述', '1378898976', '1379235841', '1', '金方时代内容管理框架金方时代内容管理框架金方时代内容管理框架', '1');
INSERT INTO `jfsd_config` VALUES ('3', 'WEB_SITE_KEYWORD', '2', '网站关键字', '1', '', '网站搜索引擎关键字', '1378898976', '1381390100', '1', '金方时代内容管理框架', '8');
INSERT INTO `jfsd_config` VALUES ('4', 'WEB_SITE_CLOSE', '4', '关闭站点', '1', '0:关闭,1:开启', '站点关闭后其他用户不能访问，管理员可以正常访问', '1378898976', '1379235296', '1', '1', '1');
INSERT INTO `jfsd_config` VALUES ('5', 'CONFIG_TYPE_LIST', '3', '配置类型列表', '0', '', '主要用于数据解析和页面表单的生成', '1378898976', '1442375762', '1', '0:数字\r\n1:字符\r\n2:文本\r\n3:数组\r\n4:枚举', '2');
INSERT INTO `jfsd_config` VALUES ('6', 'APPID', '1', 'APPID', '2', '', '微信公众平台APPID', '1378900335', '1444806653', '1', 'wxc6fb3617eba12b28', '9');
INSERT INTO `jfsd_config` VALUES ('7', 'CONFIG_GROUP_LIST', '3', '配置分组', '4', '', '配置分组', '1379228036', '1444806460', '1', '1:基本\r\n2:微信配置\r\n3:产品配置\r\n5:店铺配置\r\n4:系统', '4');
INSERT INTO `jfsd_config` VALUES ('9', 'ADMIN_LIST_ROWS', '0', '后台每页记录数', '4', '', '后台数据每页显示记录数，默认10', '1379503896', '1436427099', '1', '15', '20');
INSERT INTO `jfsd_config` VALUES ('10', 'PRODUCT_CATE', '3', '产品分类', '3', '', '产品分类', '1379504487', '1444807153', '1', '1:紫砂陶瓷\r\n2:玉翠珠宝\r\n3:书画篆刻\r\n4:文玩收藏\r\n5:特色珍品\r\n6:其他', '3');
INSERT INTO `jfsd_config` VALUES ('12', 'TOKEN', '1', 'TOKEN', '2', '', '微信公众平台TOKEN', '1386645376', '1444806754', '1', '123456', '0');
INSERT INTO `jfsd_config` VALUES ('13', 'ADMIN_ALLOW_IP', '2', '后台允许访问IP', '0', '', '多个用逗号分隔，如果不配置表示不限制IP访问', '1387165454', '1442369565', '1', '', '12');
INSERT INTO `jfsd_config` VALUES ('14', 'DEVELOP_MODE', '4', '开发者模式', '4', '0:关闭\r\n1:开启', '是否开启开发者模式', '1387165685', '1444816978', '1', '1', '0');
INSERT INTO `jfsd_config` VALUES ('15', 'IS_ROOT', '3', '超级管理员', '0', '', '超级管理员用户uid', '1435728710', '1442310051', '1', '1', '0');
INSERT INTO `jfsd_config` VALUES ('16', 'CATEGORY_TYPE', '3', '栏目类型', '0', '', '栏目类型', '1436250193', '1442384601', '1', 'News:新闻\r\nPages:单页\r\nProduct:产品', '0');
INSERT INTO `jfsd_config` VALUES ('17', 'POSTAGE_LIST', '3', '运费列表', '3', '', '运费列表', '1436508822', '1445330547', '1', '10\r\n15\r\n20\r\n30\r\n50\r\n100', '0');
INSERT INTO `jfsd_config` VALUES ('18', 'PRODUCT_IMG_MAX', '0', '产品图片最多', '3', '', '产品图片最多', '1436508899', '1445308843', '1', '6', '0');
INSERT INTO `jfsd_config` VALUES ('19', 'BANNER_TYPE', '3', '广告位类型', '0', '', '广告位类型', '1436770102', '1442384478', '1', '1:单条\r\n2:多条', '0');
INSERT INTO `jfsd_config` VALUES ('20', 'APPSECRET', '1', 'APPSECRET', '2', '', '微信公众平台APPSECRET', '1437116639', '1444806700', '1', '4936a53a2583060d0abd7c9893916591', '0');
INSERT INTO `jfsd_config` VALUES ('21', 'WEB_SITE_URL', '1', '网站域名', '1', '', '网站域名 如：http://wwb.sypole.com 不加/', '1441699978', '1444817408', '1', 'http://wwb.sypole.com', '0');
INSERT INTO `jfsd_config` VALUES ('22', 'PRODUCT_TYPE', '3', '产品类型', '3', '', '产品类型', '1444807387', '1444807387', '1', '1:加价拍\r\n2:竞速拍\r\n3:秒杀拍', '0');
INSERT INTO `jfsd_config` VALUES ('23', 'SHOP_GROUP', '3', '店铺等级', '5', '', '店铺等级', '1447403416', '1447404393', '1', '1:VIP1\r\n2:VIP2\r\n3:VIP3\r\n4:VIP4\r\n5:VIP5\r\n6:VIP6', '0');

-- -----------------------------
-- Table structure for `jfsd_link`
-- -----------------------------
DROP TABLE IF EXISTS `jfsd_link`;
;


-- -----------------------------
-- Table structure for `jfsd_message`
-- -----------------------------
DROP TABLE IF EXISTS `jfsd_message`;
;


-- -----------------------------
-- Table structure for `jfsd_news`
-- -----------------------------
DROP TABLE IF EXISTS `jfsd_news`;
;


-- -----------------------------
-- Table structure for `jfsd_pages`
-- -----------------------------
DROP TABLE IF EXISTS `jfsd_pages`;
;


-- -----------------------------
-- Table structure for `jfsd_product`
-- -----------------------------
DROP TABLE IF EXISTS `jfsd_product`;
;

-- -----------------------------
-- Records of `jfsd_product`
-- -----------------------------
INSERT INTO `jfsd_product` VALUES ('1', '1', '4', '2', '一件衣服', '一件衣服以起拍价开始竞拍，由低到高出价，出价金额不小于当前价与加价幅度之和\r\n结拍后，出价最高者得拍；若最高出价低于保留价，则拍品流拍', '[\".\\/Uploads\\/Product\\/2015-10-20\\/E8PySYh3jBtp69QCF4s-CGkL7HMSPCX1UuNb6upZhjjZKzmhmmrPGCxfOwr5xV7x.jpg\",\".\\/Uploads\\/Product\\/2015-10-20\\/4K33poNUcFSvO703pK4kf17KFOqRnmJWyj2-DRLUDoCmIqni9edMhmUGqdoIEJF3.jpg\"]', '1445878800', '1445882400', '50', '10', '500', '0', '0', '6', '0', '1445328930', '1445586715', '0', '1', '0', '0', '0');
INSERT INTO `jfsd_product` VALUES ('3', '1', '2', '2', '你回去', '去兔兔兔兔兔兔了啦啦啦啦', '[\".\\/Uploads\\/Product\\/2015-10-21\\/gA8lSOl_VJlchw1UD0KlJ4TDB-nPvwYNXhPdCi75Xo2vAD_8w_Udcj4GGe5D9F82.jpg\",\".\\/Uploads\\/Product\\/2015-10-21\\/a3-WiRcg4UgAa2Y2JrnfS1mt2e_bpgYtsIO8NSrNa8oLOjASmgj31wHrqT6qMpkR.jpg\",\".\\/Uploads\\/Product\\/2015-10-21\\/RnoC1WeOIiGGSFxI0fzjaREDeJj_ya_kzCp6mh_O7GamX8wZpESg0JIIbNSxX1MQ.jpg\"]', '1445385600', '1446595200', '100', '200', '20000', '0', '0', '0', '0', '1445393013', '1445396018', '0', '0', '0', '0', '0');
INSERT INTO `jfsd_product` VALUES ('4', '2', '2', '2', '一件衣服', '一件衣服', '[\".\\/Uploads\\/Product\\/2015-10-20\\/E8PySYh3jBtp69QCF4s-CGkL7HMSPCX1UuNb6upZhjjZKzmhmmrPGCxfOwr5xV7x.jpg\",\".\\/Uploads\\/Product\\/2015-10-20\\/4K33poNUcFSvO703pK4kf17KFOqRnmJWyj2-DRLUDoCmIqni9edMhmUGqdoIEJF3.jpg\"]', '0', '0', '0', '0', '0', '0', '0', '0', '0', '1445398714', '0', '0', '0', '0', '0', '0');
INSERT INTO `jfsd_product` VALUES ('5', '2', '2', '2', '一件衣服', '一件衣服', '[\".\\/Uploads\\/Product\\/2015-10-20\\/E8PySYh3jBtp69QCF4s-CGkL7HMSPCX1UuNb6upZhjjZKzmhmmrPGCxfOwr5xV7x.jpg\",\".\\/Uploads\\/Product\\/2015-10-20\\/4K33poNUcFSvO703pK4kf17KFOqRnmJWyj2-DRLUDoCmIqni9edMhmUGqdoIEJF3.jpg\"]', '0', '0', '0', '0', '0', '0', '0', '0', '0', '1445398736', '0', '0', '0', '0', '0', '0');
INSERT INTO `jfsd_product` VALUES ('6', '2', '1', '2', '一件衣服21341234', '一件衣服21341234', '[\".\\/Uploads\\/Product\\/2015-10-20\\/E8PySYh3jBtp69QCF4s-CGkL7HMSPCX1UuNb6upZhjjZKzmhmmrPGCxfOwr5xV7x.jpg\",\".\\/Uploads\\/Product\\/2015-10-20\\/4K33poNUcFSvO703pK4kf17KFOqRnmJWyj2-DRLUDoCmIqni9edMhmUGqdoIEJF3.jpg\"]', '1447113600', '1448323200', '10', '50', '0', '0', '0', '2', '0', '1445398743', '1447134387', '0', '1', '0', '0', '0');
INSERT INTO `jfsd_product` VALUES ('7', '2', '2', '2', '一件衣服21341234132', '一件衣服21341234', '[\".\\/Uploads\\/Product\\/2015-10-20\\/E8PySYh3jBtp69QCF4s-CGkL7HMSPCX1UuNb6upZhjjZKzmhmmrPGCxfOwr5xV7x.jpg\",\".\\/Uploads\\/Product\\/2015-10-20\\/4K33poNUcFSvO703pK4kf17KFOqRnmJWyj2-DRLUDoCmIqni9edMhmUGqdoIEJF3.jpg\"]', '0', '0', '0', '0', '0', '0', '0', '0', '0', '1445398747', '0', '0', '0', '0', '0', '0');
INSERT INTO `jfsd_product` VALUES ('8', '2', '2', '2', '一件衣服21341234132', '一件衣服21341234', '[\".\\/Uploads\\/Product\\/2015-10-20\\/E8PySYh3jBtp69QCF4s-CGkL7HMSPCX1UuNb6upZhjjZKzmhmmrPGCxfOwr5xV7x.jpg\",\".\\/Uploads\\/Product\\/2015-10-20\\/4K33poNUcFSvO703pK4kf17KFOqRnmJWyj2-DRLUDoCmIqni9edMhmUGqdoIEJF3.jpg\"]', '0', '0', '0', '0', '0', '0', '0', '0', '0', '1445398749', '0', '0', '0', '0', '0', '0');
INSERT INTO `jfsd_product` VALUES ('9', '3', '3', '2', '一件衣服21341234132', '一件衣服21341234', '[\"\\/Uploads\\/Product\\/2015-10-20\\/E8PySYh3jBtp69QCF4s-CGkL7HMSPCX1UuNb6upZhjjZKzmhmmrPGCxfOwr5xV7x.jpg\",\".\\/Uploads\\/Product\\/2015-10-20\\/4K33poNUcFSvO703pK4kf17KFOqRnmJWyj2-DRLUDoCmIqni9edMhmUGqdoIEJF3.jpg\"]', '1445385600', '1457817600', '0', '100', '0', '0', '0', '14', '0', '1445398751', '1447134397', '0', '1', '0', '0', '0');
INSERT INTO `jfsd_product` VALUES ('10', '3', '2', '2', '未开始.........', '一件衣服21341234', '[\"\\/Uploads\\/Product\\/2015-10-20\\/E8PySYh3jBtp69QCF4s-CGkL7HMSPCX1UuNb6upZhjjZKzmhmmrPGCxfOwr5xV7x.jpg\",\".\\/Uploads\\/Product\\/2015-10-20\\/4K33poNUcFSvO703pK4kf17KFOqRnmJWyj2-DRLUDoCmIqni9edMhmUGqdoIEJF3.jpg\"]', '1445558400', '1466644800', '0', '100', '0', '0', '0', '19', '0', '1445398754', '1445489428', '0', '1', '0', '1', '0');
INSERT INTO `jfsd_product` VALUES ('11', '2', '2', '2', '一件衣服21341234132', '一件衣服21341234', '[\"\\/Uploads\\/Product\\/2015-10-20\\/E8PySYh3jBtp69QCF4s-CGkL7HMSPCX1UuNb6upZhjjZKzmhmmrPGCxfOwr5xV7x.jpg\",\".\\/Uploads\\/Product\\/2015-10-20\\/4K33poNUcFSvO703pK4kf17KFOqRnmJWyj2-DRLUDoCmIqni9edMhmUGqdoIEJF3.jpg\"]', '1447113600', '1448323200', '0', '100', '0', '0', '0', '3', '0', '1445398812', '1447134417', '0', '1', '0', '0', '0');
INSERT INTO `jfsd_product` VALUES ('12', '2', '2', '2', '一件衣服21341234132', '一件衣服21341234', '[\"\\/Uploads\\/Product\\/2015-10-20\\/E8PySYh3jBtp69QCF4s-CGkL7HMSPCX1UuNb6upZhjjZKzmhmmrPGCxfOwr5xV7x.jpg\",\".\\/Uploads\\/Product\\/2015-10-20\\/4K33poNUcFSvO703pK4kf17KFOqRnmJWyj2-DRLUDoCmIqni9edMhmUGqdoIEJF3.jpg\"]', '0', '0', '0', '0', '0', '0', '0', '0', '0', '1445398824', '1445399495', '0', '0', '0', '0', '0');
INSERT INTO `jfsd_product` VALUES ('13', '1', '1', '2', '拍卖中.........', '拍卖中.........', '[\"\\/Uploads\\/Product\\/2015-10-20\\/E8PySYh3jBtp69QCF4s-CGkL7HMSPCX1UuNb6upZhjjZKzmhmmrPGCxfOwr5xV7x.jpg\",\".\\/Uploads\\/Product\\/2015-10-20\\/4K33poNUcFSvO703pK4kf17KFOqRnmJWyj2-DRLUDoCmIqni9edMhmUGqdoIEJF3.jpg\"]', '1445472000', '1445558400', '1', '10', '0', '0', '0', '0', '0', '1445398902', '1445489224', '0', '1', '0', '0', '0');
INSERT INTO `jfsd_product` VALUES ('14', '1', '3', '2', '一件衣服', '一件衣服', '[\"\\/Uploads\\/Product\\/2015-10-20\\/E8PySYh3jBtp69QCF4s-CGkL7HMSPCX1UuNb6upZhjjZKzmhmmrPGCxfOwr5xV7x.jpg\",\".\\/Uploads\\/Product\\/2015-10-20\\/4K33poNUcFSvO703pK4kf17KFOqRnmJWyj2-DRLUDoCmIqni9edMhmUGqdoIEJF3.jpg\"]', '1445472000', '1446336000', '100', '50', '80000', '0', '50', '11', '0', '1445399000', '1445407110', '0', '1', '0', '0', '0');
INSERT INTO `jfsd_product` VALUES ('15', '1', '3', '2', '一件衣服', '一件衣服', '[\"\\/Uploads\\/Product\\/2015-10-20\\/E8PySYh3jBtp69QCF4s-CGkL7HMSPCX1UuNb6upZhjjZKzmhmmrPGCxfOwr5xV7x.jpg\",\".\\/Uploads\\/Product\\/2015-10-20\\/4K33poNUcFSvO703pK4kf17KFOqRnmJWyj2-DRLUDoCmIqni9edMhmUGqdoIEJF3.jpg\"]', '1445472000', '1446595200', '0', '1', '0', '0', '0', '6', '0', '1445399042', '1445405920', '0', '1', '0', '0', '0');

-- -----------------------------
-- Table structure for `jfsd_product_bid`
-- -----------------------------
DROP TABLE IF EXISTS `jfsd_product_bid`;
;

-- -----------------------------
-- Records of `jfsd_product_bid`
-- -----------------------------
INSERT INTO `jfsd_product_bid` VALUES ('1', '15', '2', '1', '1445477933', '1445477933', '1');
INSERT INTO `jfsd_product_bid` VALUES ('2', '15', '2', '1', '1445477937', '1445477937', '1');
INSERT INTO `jfsd_product_bid` VALUES ('3', '15', '2', '1', '1445477943', '1445477943', '1');
INSERT INTO `jfsd_product_bid` VALUES ('4', '15', '2', '2', '1445477946', '1445477946', '1');
INSERT INTO `jfsd_product_bid` VALUES ('5', '15', '2', '1', '1445478624', '1445478624', '1');
INSERT INTO `jfsd_product_bid` VALUES ('6', '15', '2', '1', '1445478626', '1445478626', '1');
INSERT INTO `jfsd_product_bid` VALUES ('7', '15', '2', '1', '1445478629', '1445478629', '1');
INSERT INTO `jfsd_product_bid` VALUES ('8', '15', '2', '4', '1445478674', '1445478674', '1');
INSERT INTO `jfsd_product_bid` VALUES ('9', '15', '2', '5', '1445478998', '1445478998', '1');
INSERT INTO `jfsd_product_bid` VALUES ('10', '15', '2', '6', '1445479467', '1445479467', '1');
INSERT INTO `jfsd_product_bid` VALUES ('11', '15', '2', '7', '1445480082', '1445480082', '1');
INSERT INTO `jfsd_product_bid` VALUES ('12', '15', '2', '8', '1445483462', '1445483462', '1');
INSERT INTO `jfsd_product_bid` VALUES ('13', '15', '2', '9', '1445483467', '1445483467', '1');
INSERT INTO `jfsd_product_bid` VALUES ('14', '15', '2', '10', '1445483487', '1445483487', '1');
INSERT INTO `jfsd_product_bid` VALUES ('15', '14', '2', '100', '1445485221', '1445485221', '1');
INSERT INTO `jfsd_product_bid` VALUES ('16', '13', '2', '1', '1445507364', '1445507364', '1');
INSERT INTO `jfsd_product_bid` VALUES ('17', '10', '2', '100', '1445586441', '1445586441', '1');
INSERT INTO `jfsd_product_bid` VALUES ('18', '10', '5', '200', '1445825518', '1445825518', '1');
INSERT INTO `jfsd_product_bid` VALUES ('19', '10', '2', '300', '1446793111', '1446793111', '1');
INSERT INTO `jfsd_product_bid` VALUES ('20', '9', '2', '300', '1447064796', '1447064796', '1');

-- -----------------------------
-- Table structure for `jfsd_product_collect`
-- -----------------------------
DROP TABLE IF EXISTS `jfsd_product_collect`;
;

-- -----------------------------
-- Records of `jfsd_product_collect`
-- -----------------------------
INSERT INTO `jfsd_product_collect` VALUES ('2', '2', '1', '1445417762', '1445587247', '1');
INSERT INTO `jfsd_product_collect` VALUES ('3', '2', '13', '1445489234', '1445497349', '0');
INSERT INTO `jfsd_product_collect` VALUES ('4', '3', '10', '1446024143', '1446024145', '0');

-- -----------------------------
-- Table structure for `jfsd_user`
-- -----------------------------
DROP TABLE IF EXISTS `jfsd_user`;
;

-- -----------------------------
-- Records of `jfsd_user`
-- -----------------------------
INSERT INTO `jfsd_user` VALUES ('2', 'o4I-2uMfbRWV-KlcnujVL2JP8KZU', '吴文豹', '1', '6', '1', 'http://wx.qlogo.cn/mmopen/IzbYJ7aU1hJEXRCzC3YYVSVdGpKJBSZL5C77zlmdakz87iaAGicicMrZGECgGvfscejDaIupibibEcqUCiaVwuZMjGLXLppFOoibAfS/0', '15044858848', 'wwb572300808', '主营项目', '起来了你回来估计可以理解具体啦啦啦', '{\"province\":\"\\u5185\\u8499\\u53e4\",\"city\":\"\\u5df4\\u5f66\\u6dd6\\u5c14\",\"area\":\"\\u4e4c\\u62c9\\u7279\\u4e2d\"}', '1447406611', '1447406611', '1');
INSERT INTO `jfsd_user` VALUES ('3', 'o4I-2uKFNM1Ax0pHH63gVidpKpeM', 'Mr,Y', '1', '6', '1', 'http://wx.qlogo.cn/mmopen/M0DJF8IibBRN8qfM2iaB1VFA5ftSGmmMNZtNC5lAHMo7dSCjA08OzBGT7Pd1S7VIOIwYhrZIZNBqTHGBb0QMiaqCtbU1OBYT6Oa/0', '13986765412', '', '', '', '', '1447406722', '1447406722', '1');
INSERT INTO `jfsd_user` VALUES ('4', 'o4I-2uClSMIuFAtKkb-QSmcPJTtU', '二帮榔', '1', '6', '1', 'http://wx.qlogo.cn/mmopen/ajNVdqHZLLAP6rerZLWWaIOD5t4MvqQichuIH0ZJ5IrdBWLq3ibWEQAKnYoHpZoo6YqlMHvTR2aoFYzPvk8gCsyQ/0', '', '', '', '', '', '1447406734', '1447406734', '1');
INSERT INTO `jfsd_user` VALUES ('5', 'o4I-2uIrQlaV0KaJvX6QKEvGjpj4', '哈哈哈', '1', '1', '1', 'http://wx.qlogo.cn/mmopen/M0DJF8IibBRN8qfM2iaB1VFFeGHTobhQ3ibe5TgznBr8MAib8Pj3ZoDz54fV3PlH0gVGuvuZibp5FBIxR22LRqbZNoR6SmOnPAicg1/0', '', '', '', '', '', '1447407145', '1447407145', '1');
INSERT INTO `jfsd_user` VALUES ('6', 'o4I-2uIJ3uc4W_VHE1RcQd8YPipk', '等', '1', '6', '1', 'http://wx.qlogo.cn/mmopen/RdLHh6hsfrySkgNibafIzyARY4nQfW6eF3bU2Xqoa98hfqd00ia4JUvibPY4Noq5TU0naRB2rBdia2QSANMSvM1F8b0tXibXia54ZF/0', '', '', '', '', '', '1447406728', '1447406728', '1');

-- -----------------------------
-- Table structure for `jfsd_user_collect`
-- -----------------------------
DROP TABLE IF EXISTS `jfsd_user_collect`;
;

-- -----------------------------
-- Records of `jfsd_user_collect`
-- -----------------------------
INSERT INTO `jfsd_user_collect` VALUES ('1', '2', '2', '1445225860', '1446103694', '1');
INSERT INTO `jfsd_user_collect` VALUES ('2', '2', '3', '1447407069', '1447407069', '1');

-- -----------------------------
-- Table structure for `jfsd_user_consign`
-- -----------------------------
DROP TABLE IF EXISTS `jfsd_user_consign`;
;

-- -----------------------------
-- Records of `jfsd_user_consign`
-- -----------------------------
INSERT INTO `jfsd_user_consign` VALUES ('2', '2', '吴文豹', '15044858848', '{\"province\":\"\\u5185\\u8499\\u53e4\",\"city\":\"\\u5df4\\u5f66\\u6dd6\\u5c14\",\"area\":\"\\u4e4c\\u62c9\\u7279\\u4e2d\"}', '时代风帆大赛', '001500', '1', '1444906768', '1444977846', '1');
INSERT INTO `jfsd_user_consign` VALUES ('3', '2', '吴文豹', '15044858848', '{\"province\":\"\\u5317\\u4eac\",\"city\":\"\\u5317\\u4eac\",\"area\":\"\\u4e1c\\u57ce\"}', '北京', '015000', '0', '1444958748', '1444976827', '1');
INSERT INTO `jfsd_user_consign` VALUES ('4', '2', '回来了', '15044858848', '{\"province\":\"\\u5317\\u4eac\",\"city\":\"\\u5317\\u4eac\",\"area\":\"\\u77f3\\u666f\\u5c71\"}', '搞茉莉', '015000', '0', '1444977524', '1444977653', '1');
INSERT INTO `jfsd_user_consign` VALUES ('5', '2', '家里人', '1554', '{\"province\":\"\\u5317\\u4eac\",\"city\":\"\\u5317\\u4eac\",\"area\":\"\\u6d77\\u6dc0\"}', '根据', '077855', '0', '1444977706', '1444977717', '1');
